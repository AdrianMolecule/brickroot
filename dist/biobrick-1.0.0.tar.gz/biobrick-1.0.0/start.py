from brickpackage.MainUI import *

mainUI("")

# pip uninstall dnachisel --no-cache-dir
# pip install # pip install pandas 
 